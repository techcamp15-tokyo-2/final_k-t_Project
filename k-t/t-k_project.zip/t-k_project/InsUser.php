<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
  </head>
  <body>
    <?php
       /*****受け取ったデータをインサート*****/
       $url = parse_url(getenv("CLEARDB_DATABASE_URL"));

       $server = $url["host"];
       $username = $url["user"];
       $password = $url["pass"];
       $db = substr($url["path"], 1);
       
       $link = mysql_connect($server, $username, $password);

       if (!$link) {
         die('接続失敗です。'.mysql_error());
       }
       
       print('<p>接続に成功しました。</p>');



       $db_selected = mysql_select_db($db);
       if (!$db_selected){
         die('データベース選択失敗です。'.mysql_error());
       }
       
       print('<p>uriageデータベースを選択しました。</p>');
       




       mysql_set_charset('utf8');
       
       $result = mysql_query('SELECT * FROM user_data');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }
       

       while ($row = mysql_fetch_assoc($result)) {
         print('<p>');
         print('id='.$row['id']);
         print(',name='.$row['name']);
         print('</p>');

         if($_POST[0] === $row['name']){
           $state = 1;
           break;
         }else{
           $state = 0;  
         }

       }




       if($state == 0){
         print('<p>データを追加します。</p>');
       
         $sql = "INSERT INTO user_data (id, name, uuid, device) VALUES (NULL, '$_POST[0]', '$_POST[1]', '$_POST[2]')";
         $result_flag = mysql_query($sql);
       
         if (!$result_flag) {
           die('INSERTクエリーが失敗しました。'.mysql_error());
         }
       }



       /*
       print('<p>追加後のデータを取得します。</p>');
       
       $result = mysql_query('SELECT id,name FROM shouhin');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }
       
       while ($row = mysql_fetch_assoc($result)) {
         print('<p>');
         print('id='.$row['id']);
         print(',name='.$row['name']);
         print('</p>');
       }
       */



       $close_flag = mysql_close($link);
       
       if ($close_flag){
         print('<p>切断に成功しました。</p>');
       }
       ?>
  </body>
</html>
