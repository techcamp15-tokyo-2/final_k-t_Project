<?php



//データベースから値を取得してくる処理(始まり)

//Ajax通信ではなく、直接URLを叩かれた場合はエラーメッセージを表示
//if (
    //!(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') 
    //&& (!empty($_SERVER['SCRIPT_FILENAME']) && 'json.php' === basename($_SERVER['SCRIPT_FILENAME']))
    //) 
//{
    //die ('このページは直接ロードしないで下さい。');
//}
 
//接続文字列 (PHP5.3.6から文字コードが指定できるようになりました)
//$dsn = 'mysql:dbname=b1_sato;host=localhost;charset=utf8';
 
//ユーザ名
//$user = 'b1_sato';
 
//パスワード
//$password = 'b1_sato';
 
//try
//{
    //nullで初期化
    //$users = null;
     
    //DBに接続
    //$dbh = new PDO($dsn, $user, $password);
     
    //'users' テーブルのデータを取得する
    //$sql = 'select year,month,day,hour,minute from CA where ';
    //$stmt = $dbh->query($sql);
     
    //送信したい日時を配列に格納
    //while ($row = $stmt->fetchObject())
    //{
       // $send_date[] = array(
            
//'year'=>$row->year,
//'month'=>$row->month,

//'day'=>$row->day,

//'hour'=>$row->hour,
//'minute'=>$row->minute          
            //);
            //if($today_date['year']==$send_date['year']&&
            //$today_date['month']==$send_date['month']&&
            //$today_date['day']==$send_date['day']&&
           // $today_date['hour']==$send_date['hour']&&
            //$today_date['minute']==$send_date['minute'])
            
            
           // { //受け取る人のidを取ってくる
            
            //$sql2 = 'select receive_name from CA';
    	    	      //$receive_id = $dbh->query($sql2);
    		      		      //$device ='select id from user_data where $receive_id';
    				      			 
									//}
											
													//echo $receive_id;
   // }
    
    
	//今日の日時を配列に取得
  //$today_date = date('Y-m-d H:i:s', time());
//$keys = array('year', 'month', 'day', 'hour', 'minute', 'second');
//$today_date = array_combine($keys, preg_split('/[-: ]/', $today_date));  
      
//}



//catch (PDOException $e)
//{
    //例外処理
    //die('Error:' . $e->getMessage());
    //}
    
    

//データベースから値を取得してくる処理(終わり)





/**
 * @file
 * sample_push.php
 *
 * Push demo
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://code.google.com/p/apns-php/wiki/License
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to aldo.armiento@gmail.com so we can send you a copy immediately.
 *
 * @author (C) 2010 Aldo Armiento (aldo.armiento@gmail.com)
 * @version $Id: sample_push.php 65 2010-12-13 18:38:39Z aldo.armiento $
 */

// Adjust to your timezone
date_default_timezone_set('Europe/Rome');

// Report all PHP errors
error_reporting(-1);

// Using Autoload all classes are loaded on-demand
require_once 'ApnsPHP/Autoload.php';

// Instanciate a new ApnsPHP_Push object
$push = new ApnsPHP_Push(
      ApnsPHP_Abstract::ENVIRONMENT_SANDBOX,
      // 修正前
      // 'server_certificates_bundle_sandbox.pem',
        // 修正後
	'certificates/AppNameDev.pem'
);

// Set the Root Certificate Autority to verify the Apple remote peer
// 修正前
// $push->setRootCertificationAuthority('entrust_root_certification_authority.pem');
// 修正後
$push->setRootCertificationAuthority('certificates/entrust_root_certification_authority.pem');
// Connect to the Apple Push Notification Service
$push->connect();

    

       $url = parse_url(getenv("CLEARDB_DATABASE_URL"));

       $server = $url["host"];
       $username = $url["user"];
       $password = $url["pass"];
       $db = substr($url["path"], 1);
       
       $link = mysql_connect($server, $username, $password);

       if (!$link) {
         die('接続失敗です。'.mysql_error());
       }
       
       print('<p>接続に成功しました。</p>');



       $db_selected = mysql_select_db($db);
       if (!$db_selected){
         die('データベース選択失敗です。'.mysql_error());
       }
       
       print('<p>uriageデータベースを選択しました。</p>');
       




       mysql_set_charset('utf8');
       
       $result = mysql_query('SELECT * FROM ca');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }
       
       

       $i = 0;
       $r_name = array();
       while ($row = mysql_fetch_assoc($result)) {
         print('<p>');
         print('id='.$row['id']);
         print('</p>');

	  $intMinute = intval($row['minute']);
	   $nowMinute = intval(date('i'));
	    $ten = $nowMinute - 10;

         if(date('Y') == $row['year'] && date('m') == $row['month'] && date('d') == $row['day'] && date('G') == $row['hour']){

	      if($nowMinute >= $intMinute && $ten <= $intMinute){
	           $r_name[] = $row['receive_name'];
		        $i++;
//			     print('name:'.$r_name[$i]);
			          print('<br>');
//				       error_log($r_name[$i]);
				            print('i:'. $i);
					         print('<br>');
						    }
						     }

       }
        
	print_r($r_name);
	print('<br>');


       mysql_set_charset('utf8');
       
       $result = mysql_query('SELECT * FROM user_data');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }
       

       print('-------------------------------------------------<br>');

       $device = array();
       $j = 0;
       while ($row = mysql_fetch_assoc($result)) {
         for($k = 0; $k < $i; $k++){
	      print('2_id:'.$row['id']);
	           print('<br>');
		        print('r_name:'.$r_name[$k]);
			     print('<br>');
           if($r_name[$k] == $row['id']){
	        $device[$k] = $row['device'];
		     print('device:'.$device[$k]);
		          print('<br>');
			     }
			          print('2_i:'.$i);
				       print('<br>');
				            print('k:'.$k);
					         print('<br>');

						  }
						   print('j:'.$j);
						    print('<br>');
						     print('==========================<br>');
						      $j++;
       }

    
    print_r($device);




// Instantiate a new Message with a single recipient
// 修正前
// $message = new ApnsPHP_Message('9e1791742ce6658f0d04128ec05ae4ed9858e534ff6ae6e8e18c68ded547ba0b');
// 修正後
//$message = new ApnsPHP_Message('267c6f0dd1d653a7a91dc5df6064b9cf83f238c5bf7d493f773cbff6e091fe17');

for($l = 0; $l < count($device); $l++){
$message = new ApnsPHP_Message('$device[$l]');



// Set a custom identifier. To get back this identifier use the getCustomIdentifier() method
// over a ApnsPHP_Message object retrieved with the getErrors() message.
$message->setCustomIdentifier("Message-Badge-3");

// Set badge icon to "3"
$message->setBadge(3);

// Set a simple welcome text
$message->setText('Hello APNs-enabled device!');

// Play the default sound
$message->setSound();

// Set a custom property
$message->setCustomProperty('acme2', array('bang', 'whiz'));

// Set another custom property
$message->setCustomProperty('acme3', array('bing', 'bong'));

// Set the expiry value to 30 seconds
$message->setExpiry(30);

// Add the message to the message queue
$push->add($message);


// たぶんここまで
}



// Send all messages in the message queue
$push->send();

// Disconnect from the Apple Push Notification Service
$push->disconnect();

// Examine the error message container
$aErrorQueue = $push->getErrors();
if (!empty($aErrorQueue)) {
   var_dump($aErrorQueue);
}