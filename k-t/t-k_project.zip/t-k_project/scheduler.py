#!/usr/local/bin/python

import urllib

url = "http://t-kproject.herokuapp.com/sample_push.php"
urllib.urlopen(url)

print "OK"
