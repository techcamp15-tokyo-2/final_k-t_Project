<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
  </head>
  <body>
    <?php
       /*****受け取ったデータをインサート*****/
       $url = parse_url(getenv("CLEARDB_DATABASE_URL"));

       $server = $url["host"];
       $username = $url["user"];
       $password = $url["pass"];
       $db = substr($url["path"], 1);
       
       $link = mysql_connect($server, $username, $password);

       if (!$link) {
         die('接続失敗です。'.mysql_error());
       }
       
       print('<p>接続に成功しました。</p>');



       $db_selected = mysql_select_db($db);
       if (!$db_selected){
         die('データベース選択失敗です。'.mysql_error());
       }
       
       print('<p>uriageデータベースを選択しました。</p>');
       




       mysql_set_charset('utf8');
       
       $result = mysql_query('SELECT * FROM user_data');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }



       for ($i = 0; $row = mysql_fetch_assoc($result); $i++) {
         print('<p>');
         print('id='.$row['id']);
         print(',name='.$row['name']);
         print('</p>');

       // 受信者の名前なら
         if($row['name'] === $_POST[0]){
//           echo "r_id:" . $r_id . "\nrow_name:$row['name']\npost:$_POST[0]\n"
           $r_id = $row['id'];
         }

       // 送信者の名前なら
         if($row['name'] === $_POST[1]){
//           echo "s_id:" . $r_id . "\nrow_name:$row['name']\npost:$_POST[1]\n"
           $s_id = $row['id'];
         }
       }



       
       mysql_set_charset('utf8');
       
       $result = mysql_query('SELECT * FROM CA');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }


       
       print('<p>データを追加します。</p>');
       
       $sql = "INSERT INTO CA (id, receive_name, send_name, year, month, day, hour, minute, place, message) VALUES (NULL, '$r_id', '$s_id', '$_POST[2]', '$_POST[3]', '$_POST[4]', '$_POST[5]', '$_POST[6]', '$_POST[7]', '$_POST[8]')";
       $result_flag = mysql_query($sql);
       
       if (!$result_flag) {
         die('INSERTクエリーが失敗しました。'.mysql_error());
       }



       /*
       print('<p>追加後のデータを取得します。</p>');
       
       $result = mysql_query('SELECT id,name FROM shouhin');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }
       
       while ($row = mysql_fetch_assoc($result)) {
         print('<p>');
         print('id='.$row['id']);
         print(',name='.$row['name']);
         print('</p>');
       }
       */



       $close_flag = mysql_close($link);
       
       if ($close_flag){
         print('<p>切断に成功しました。</p>');
       }
       ?>
  </body>
</html>
