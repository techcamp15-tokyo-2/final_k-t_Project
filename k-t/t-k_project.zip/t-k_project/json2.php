<?php
    //Ajax通信ではなく、直接URLを叩かれた場合はエラーメッセージを表示
    if (!(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
        && (!empty($_SERVER['SCRIPT_FILENAME']) && 'json.php' === basename($_SERVER['SCRIPT_FILENAME'])))
    {
        die ('このページは直接ロードしないで下さい。');
    }
    
    /*****受け取ったデータをインサート*****/
    $url = parse_url(getenv("CLEARDB_DATABASE_URL"));
    
    $dsn = 'mysql:dbname=heroku_2c6f4a4b848decf;host=localhost;charset=utf8';
    
    $server = $url["host"];
    $username = $url["user"];
    $password = $url["pass"];
    $db = substr($url["path"], 1);
   
    $link = mysql_connect($server, $username, $password);
   
    if (!$link) {
        die('接続失敗です。'.mysql_error());
    }
    
    //print('<p>接続に成功しました。</p>');
   
    try {
        //nullで初期化
        $users = null;
   
        $db_selected = mysql_select_db($db);
        if (!$db_selected){
            die('データベース選択失敗です。'.mysql_error());
        }
        
        //print('<p>uriageデータベースを選択しました。</p>');
        mysql_set_charset('utf8');
        //print('<p>uriageデータベースを選択しました?</p>');
        
        //print("<p>bbbbbbbbbbbbbbbbbbbbbb</p>");
        $result = mysql_query('SELECT * FROM ca');
        //print("<p>aaaaaaaaaaaaaaaaaaaaaa</p>");
        


	/*
       mysql_set_charset('utf8');
       
       $result = mysql_query('SELECT * FROM user_data');
       if (!$result) {
         die('SELECTクエリーが失敗しました。'.mysql_error());
       }
       

       $id = array();
       $name = array();
       while ($row = mysql_fetch_assoc($result)) {
	 $id[] = $row['id'];
	 $name[] = $row['name'];

       }

*/


        $result = mysql_query('SELECT * FROM ca');
        //echo "通過";
   
        if (!$result) {
            die('SELECTクエリーが失敗しました。'.mysql_error());
        }
        
	
	$r_name = array();
	$s_name = array();

   
        //取得したデータを配列に格納
	$j = 0;
        while ($row = mysql_fetch_assoc($result)) {

/*
	    for($i = 0; $i < count($id); $i++){
	      if($id[$i] == $row['receive_name']){
	        $r_name[] = $name[$i];
	      }

	      if($id[$i] == $row['send_name']){
	        $s_name[] = $name[$i];
	      }
	    }
*/

            $users[] = array(
                             'id'=>$row['id'],
                             'receive_name'=>$row['receive_name'],
                             'send_name'=>$row['send_name'],
                             'year'=>$row['year'],
                             'month'=>$row['month'],
                             'day'=>$row['day'],
                             'hour'=>$row['hour'],
                             'minute'=>$row['minute'],
                             'place'=>$row['place'],
                             'message'=>$row['message']
                             );
			     $j++;
        }
     
        //JSON形式で出力する
        header('Content-Type: application/json');
        echo json_encode( $users );
        exit;
    } catch (Exception $e) {
        //例外処理
        die('Error:' . $e->getMessage());
    }
?>
