//
//  main.m
//  storybord
//
//  Created by 夛屋 早百合 on 2013/09/09.
//  Copyright (c) 2013年 夛屋 早百合. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
