//
//  MyUrlConnDelegate.h
//  GeocodingSample-iOS5
//
//  Created by Yoshiki Komachi on 2013/09/06.
//
//

#import <Foundation/Foundation.h>

@interface MyUrlConnDelegate : NSObject
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
@end
