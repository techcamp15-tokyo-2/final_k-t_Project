//
//  MyUrlConnDelegate.m
//  GeocodingSample-iOS5
//
//  Created by Yoshiki Komachi on 2013/09/06.
//
//

#import "MyUrlConnDelegate.h"

@implementation MyUrlConnDelegate
// レスポンスを受け取った時点で呼び出される。データ受信よりも前なので注意
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"didReceiveResponse");
}

// データを受け取る度に呼び出される
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"didReceiveData");
}

// データを全て受け取ると呼び出される
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connectionDidFinishLoading");
}
@end
