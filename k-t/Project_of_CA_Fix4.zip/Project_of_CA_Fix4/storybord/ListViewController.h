//
//  ListViewController.h
//  GeocodingSample-iOS5
//
//  Created by 夛屋 早百合 on 2013/09/11.
//
//

#import <UIKit/UIKit.h>

@interface ListViewController : UITableViewController






//データの受け渡しここから

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *uuid;
@property (strong, nonatomic) NSData *device;

//データの受け渡しここまで

@end





/////*****たやさん記述*****/
////
//NSMutableData *receivedData;
////
/////*****ここまで*****/
