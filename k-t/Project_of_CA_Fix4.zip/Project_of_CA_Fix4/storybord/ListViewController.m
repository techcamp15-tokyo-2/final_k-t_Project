//  ListViewController.m
//  GeocodingSample-iOS5
//
//  Created by 夛屋 早百合 on 2013/09/11.
//
//

#import "ListViewController.h"


#define LOOP 10

@interface ListViewController ()

//// 通信用
//- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
//- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
//- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error;
//- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
//- (int)connectDB;
//

@end

@implementation ListViewController


/*********************************************ここから通信開始*********************************************/


// レスポンスを受け取った時点で呼び出される。データ受信よりも前なので注意
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"didReceiveResponse");
    [receivedData setLength:0];
}


// データを受け取る度に呼び出される
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"didReceiveData");
    [receivedData appendData:data];
}

// データを受け取る度に呼び出される
- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error
{
    //[connection release]
    if (receivedData) {
        //[receivedData release];
        receivedData = nil;
    }
    NSLog(@"Connection failed! Error - %@ %@",
          [error localizedDescription],
          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
}



// データを全て受け取ると呼び出される
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"Succeeded! Received %d bytes of data",[receivedData length]);
    //    NSLog(@"%@", [[NSString alloc]initWithData:receivedData
    //                                      encoding:NSUTF8StringEncoding]);
    
    NSLog(@"connectionDidFinishLoading");
    
    // 現在日付を取得
    NSDate *now = [NSDate date];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSUInteger flags;
    NSDateComponents *comps;
    
    // 年・月・日を取得
    flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
    comps = [calendar components:flags fromDate:now];
    
    NSInteger year = comps.year;
    NSInteger month = comps.month;
    NSInteger day = comps.day;
    
    NSLog(@"%d年 %d月 %d日", year, month, day);
    
    
    // 時・分・秒を取得
    flags = NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    comps = [calendar components:flags fromDate:now];
    
    NSInteger hour = comps.hour;
    NSInteger minute = comps.minute;
    NSInteger second = comps.second;
    
    NSLog(@"%d時 %d分 %d秒", hour, minute, second);
    
    //コピペ③始まり
    NSArray *array = [NSJSONSerialization JSONObjectWithData:receivedData options:NSJSONReadingAllowFragments error:nil];
    for (int i=0; i<[array count]; i++) {
        NSDictionary *jsonParser = [array objectAtIndex:i];        //resultを取得
        NSString* id_num = [jsonParser objectForKey:@"id"];
        NSString* receive_name = [jsonParser objectForKey:@"receive_name"];
        NSString* send_name = [jsonParser objectForKey:@"send_name"];
        NSString* strYear = [jsonParser objectForKey:@"year"];
        NSString* strMonth = [jsonParser objectForKey:@"month"];
        NSString* strDay = [jsonParser objectForKey:@"day"];
        NSString* strHour = [jsonParser objectForKey:@"hour"];
        NSString* strMinute = [jsonParser objectForKey:@"minute"];
        NSString* place = [jsonParser objectForKey:@"place"];
        NSString* message = [jsonParser objectForKey:@"message"];
        
        NSInteger intYear = [strYear integerValue];
        NSInteger intMonth = [strMonth integerValue];
        NSInteger intDay = [strDay integerValue];
        NSInteger intHour = [strHour integerValue];
        NSInteger intMinute = [strMinute integerValue];
        
        // 時間が一致していたら送信
        //        if([formatStr isEqualToString:start_date]){
        //        if(startDate <= dateNum){
        //
        
        if([receive_name isEqualToString:_name]){
            
            
            
            if(intYear < year){
                NSLog(@"id : %@", id_num);
                NSLog(@"receive_name : %@", receive_name);
                NSLog(@"send_name : %@", send_name);
                NSLog(@"year : %@", strYear);
                NSLog(@"month : %@", strMonth);
                NSLog(@"day : %@", strDay);
                NSLog(@"hour : %@", strHour);
                NSLog(@"minute : %@", strMinute);
                NSLog(@"place : %@", place);
                NSLog(@"message : %@", message);
            }else if(intYear == year){
                if(intMonth < month){
                    NSLog(@"id : %@", id_num);
                    NSLog(@"receive_name : %@", receive_name);
                    NSLog(@"send_name : %@", send_name);
                    NSLog(@"year : %@", strYear);
                    NSLog(@"month : %@", strMonth);
                    NSLog(@"day : %@", strDay);
                    NSLog(@"hour : %@", strHour);
                    NSLog(@"minute : %@", strMinute);
                    NSLog(@"place : %@", place);
                    NSLog(@"message : %@", message);
                }else if(intMonth == month){
                    if(intDay < day){
                        NSLog(@"id : %@", id_num);
                        NSLog(@"receive_name : %@", receive_name);
                        NSLog(@"send_name : %@", send_name);
                        NSLog(@"year : %@", strYear);
                        NSLog(@"month : %@", strMonth);
                        NSLog(@"day : %@", strDay);
                        NSLog(@"hour : %@", strHour);
                        NSLog(@"minute : %@", strMinute);
                        NSLog(@"place : %@", place);
                        NSLog(@"message : %@", message);
                    }else if(intDay == day){
                        if(intHour < hour){
                            NSLog(@"id : %@", id_num);
                            NSLog(@"receive_name : %@", receive_name);
                            NSLog(@"send_name : %@", send_name);
                            NSLog(@"year : %@", strYear);
                            NSLog(@"month : %@", strMonth);
                            NSLog(@"day : %@", strDay);
                            NSLog(@"hour : %@", strHour);
                            NSLog(@"minute : %@", strMinute);
                            NSLog(@"place : %@", place);
                            NSLog(@"message : %@", message);
                        }else if(intHour == hour){
                            if(intMinute <= minute){
                                NSLog(@"id : %@", id_num);
                                NSLog(@"receive_name : %@", receive_name);
                                NSLog(@"send_name : %@", send_name);
                                NSLog(@"year : %@", strYear);
                                NSLog(@"month : %@", strMonth);
                                NSLog(@"day : %@", strDay);
                                NSLog(@"hour : %@", strHour);
                                NSLog(@"minute : %@", strMinute);
                                NSLog(@"place : %@", place);
                                NSLog(@"message : %@", message);
                            }
                        }
                    }
                }
            }
        }
    }
    
    //コピペ③終わり
    //[connection release];
    if (receivedData) {
        //[receivedData release];
        receivedData = nil;
    }
}


- (void)loopProcessing
{
    NSLog(@"loopProcessing");
    [self connectDB];
    
    [self performSelector:@selector(loopProcessing) withObject:nil afterDelay:LOOP];
}


// json側のphpと接続
- (int)connectDB
{
    //コピペ①始まり
    // ここから追加
    NSURL *theURL = [NSURL URLWithString:@"http://a1.zeroprm.com/b30_c9/json2.php"];
    NSURLRequest *theRequest=[NSURLRequest requestWithURL:theURL];
    NSURLConnection *theConnection=[[NSURLConnection alloc]
                                    initWithRequest:theRequest delegate:self];
    if (theConnection) {
        NSLog(@"start loading");
        if (receivedData==nil) {
            receivedData = [[NSMutableData alloc] init];
        }
    }
    // ここまで追加
    //コピペ ①終わり
    
    return YES;
}














- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    NSLog(@"device = %@ name = %@ uuid = %@", _device, _name, _uuid);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%d", indexPath.row];
    
    
    // Configure the cell...
    
    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setValue:[NSString stringWithFormat:@"%d", indexPath.row] forKey:@"num"];
    
    [self performSegueWithIdentifier:@"rowNumber" sender:self];
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

//- (void)dealloc {
//    
//    [super dealloc];
//}
@end
