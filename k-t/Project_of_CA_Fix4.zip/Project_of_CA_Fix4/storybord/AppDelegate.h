//
//  AppDelegate.h
//  test
//
//  Created by 夛屋 早百合 on 2013/09/06.
//  Copyright (c) 2013年 夛屋 早百合. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UIViewController *viewController;

@property(nonatomic,retain)NSData* token;


@end



