//
//  ViewController.h
//  storybord
//
//  Created by 夛屋 早百合 on 2013/09/09.
//  Copyright (c) 2013年 夛屋 早百合. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "ListViewController.h"


@interface ViewController : UIViewController
<CLLocationManagerDelegate> {
    CLLocationManager *locationManager;
    //NSMutableArray *messageArray;
}
- (IBAction)done:(id)sender;

@property (nonatomic, retain) CLLocationManager *locationManager;

@property (weak, nonatomic) IBOutlet UILabel *login_name;

@property (weak, nonatomic) IBOutlet UITextField *textFieldReceiveName;


@property (weak, nonatomic) IBOutlet UITextField *textFieldSendName;

@property (weak, nonatomic) IBOutlet UITextField *textFieldYear;

@property (weak, nonatomic) IBOutlet UITextField *textFieldMonth;


@property (weak, nonatomic) IBOutlet UITextField *textFieldDay;
@property (weak, nonatomic) IBOutlet UITextField *textFieldHour;

@property (weak, nonatomic) IBOutlet UITextField *textFieldMinute;

@property (weak, nonatomic) IBOutlet UITextField *textFieldPlace;

@property (weak, nonatomic) IBOutlet UITextField *textFieldName;

@property (weak, nonatomic) IBOutlet UITextView *textFieldMessage;

- (IBAction)handleConnect:(id)sender;


- (IBAction)login_send_name:(id)sender;


@property(nonatomic,retain)NSData* device_token;

@end






