//
//  CustomIndicatorView.m
//  storybord
//
//  Created by SZK-atmosphere on 2013/09/13.
//  Copyright (c) 2013年 夛屋 早百合. All rights reserved.
//

#import "CustomIndicatorView.h"

@interface CustomIndicatorView ()

@end

@implementation CustomIndicatorView

+ (id)customIndicatorView
{
    // nib ファイルから読み込む
    UINib *nib = [UINib nibWithNibName:@"CustomIndicatorView" bundle:nil];
    CustomIndicatorView *view = [[nib instantiateWithOwner:self options:nil] objectAtIndex:0];
    view.view.layer.cornerRadius = 5;
    view.view.layer.masksToBounds = YES;
    return view;
}

- (void)startIndicatorAnimating
{
    [_indicator startAnimating];
}

- (void)stopIndicatorAnimating
{
    [_indicator stopAnimating];
}
@end
