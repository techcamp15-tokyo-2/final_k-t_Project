//
//  TableViewController.h
//  storybord
//
//  Created by 夛屋 早百合 on 2013/09/12.
//  Copyright (c) 2013年 夛屋 早百合. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomIndicatorView.h"

@interface TableViewController : UITableViewController<UITableViewDataSource, UITableViewDelegate> {
    //NSArray* datas;
    NSMutableArray *datas;
    CustomIndicatorView *indicator;
    BOOL isFirstLoad;
}


@property (strong, nonatomic) IBOutlet UITableView *tableView;



@end


///*****たやさん記述*****/
//
NSMutableData *receivedData;
//
///*****ここまで*****/

