//
//  ViewController.m
//  GeocodingSample-iOS5
//
//  Created by Yoshiki Komachi on 2013/09/05.
//  Copyright (c) 2013年 Yoshiki Komachi. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
//delegateをimport
#import "AppDelegate.h"

//#define LOOP 10


@interface ViewController ()
// 通信用
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error;
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
- (int)connectDB;

@end

@implementation ViewController



@synthesize locationManager;
@synthesize textFieldName;
@synthesize textFieldReceiveName;
@synthesize textFieldSendName;
@synthesize textFieldYear;
@synthesize textFieldMonth;
@synthesize textFieldDay;
@synthesize textFieldHour;
@synthesize textFieldMinute;
@synthesize textFieldPlace;
@synthesize textFieldMessage;


/*********************************************GPSから緯度経度を取得・場所を推定*********************************************/
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //receivedData = nil;
    
    
    //messageArray = [[NSMutableArray alloc] init];
    
    locationManager = [[CLLocationManager alloc] init];
    
    // 位置情報サービスが利用できるかどうかをチェック
    if ([CLLocationManager locationServicesEnabled]) {
        locationManager.delegate = self; // ……【1】
        // 測位開始
        [locationManager startUpdatingLocation];
    } else {
        NSLog(@"Location services not available.");
    }
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
        //[self performSelector:@selector(loopProcessing) withObject:nil afterDelay:LOOP];
    //
    AppDelegate* appdelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    _device_token = appdelegate.token;
    NSLog(@"device_token is %@",_device_token);
}






- (IBAction)login_send_name:(id)sender {
    
   
    AppDelegate* appdelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    _device_token = appdelegate.token;
    NSString* deviceToken = [[[[_device_token description]
                                stringByReplacingOccurrencesOfString: @"<" withString: @""]
                               stringByReplacingOccurrencesOfString: @">" withString: @""]
                              stringByReplacingOccurrencesOfString: @" " withString: @""];
    NSLog(@"device :::%@",deviceToken);
    NSLog(@"Login device %@",_device_token);
        
    NSString* test_uuid = @"testID";
    NSLog(@"uuid : %@",test_uuid);
  
    [self.view endEditing:NO];
    [self firstConnect:textFieldName.text uuid:test_uuid device:deviceToken];
}




////*uuidを取得
//- (NSString*) getUUID { //UUID
//    CFUUIDRef uuidObj = CFUUIDCreate(nil);
//    NSString *uuidString = (__bridge NSString*)CFUUIDCreateString(nil, uuidObj);
//    CFRelease(uuidObj);
//    return uuidString;
//    
//    
//    NSLog(@"uuid is %@",uuidString);
//
//}
//






// ユーザ名を記録する
- (int)firstConnect:(NSString*)name uuid:(NSString*)uuid device:(NSString*)device
{
    NSString* content = @"";
    NSString* formatStr = [content stringByAppendingFormat:@"0=%@&1=%@&2=%@", name, uuid, device];
    NSURL* url = [NSURL URLWithString:@"http://t-kproject.herokuapp.com/InsUser.php"];
    
    NSMutableURLRequest* urlRequest = [[NSMutableURLRequest alloc]initWithURL:url];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[formatStr dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLResponse* response;
    NSError* error = nil;
    NSData* result = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    if(error){
        NSLog(@"error = %@", error);
    }
    
    NSString* resultString
    = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    NSLog(@"%@", resultString);
    //[resultString release];
   // [urlRequest release];
    
    return YES;
    
}





- (IBAction)handleConnect:(id)sender
{
    [self.view endEditing:NO];
    [self mainConnect:textFieldReceiveName.text
             sendName:textFieldSendName.text
                 year:textFieldYear.text
                month:textFieldMonth.text
                  day:textFieldDay.text
                 hour:textFieldHour.text
               minute:textFieldMinute.text
                place:textFieldPlace.text
              message:textFieldMessage.text];
}







// 位置情報更新時
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation {
    
    //CLGeocoder *geocoder = [[[CLGeocoder alloc] init] autorelease];
    //CLLocation *location = [[[CLLocation alloc] initWithLatitude:[newLocation coordinate].latitude longitude:[newLocation coordinate].longitude] autorelease];
    //[geocoder reverseGeocodeLocation:location
                   completionHandler:^(NSArray* placemarks, NSError* error) {
                       // 経度、緯度から逆ジオコーディングを行った結果（場所）の数
                       //                       NSLog(@"found : %d", [placemarks count]);
                       
                       for (CLPlacemark *placemark in placemarks) {
                           // それぞれの結果（場所）の情報
                           //                           NSLog(@"addressDictionary : %@", [placemark.addressDictionary description]);
                           //
                           //                           NSLog(@"name : %@", placemark.name);
                           //                           NSLog(@"thoroughfare : %@", placemark.thoroughfare);
                           //                           NSLog(@"subThoroughfare : %@", placemark.subThoroughfare);
                           //                           NSLog(@"locality : %@", placemark.locality);
                           //                           NSLog(@"subLocality : %@", placemark.subLocality);
                           //                           NSLog(@"administrativeArea : %@", placemark.administrativeArea);
                           //                           NSLog(@"subAdministrativeArea : %@", placemark.subAdministrativeArea);
                           //                           NSLog(@"postalCode : %@", placemark.postalCode);
                           //                           NSLog(@"ISOcountryCode : %@", placemark.ISOcountryCode);
                           //                           NSLog(@"country : %@", placemark.country);
                           //                           NSLog(@"inlandWater : %@", placemark.inlandWater);
                           //                           NSLog(@"ocean : %@", placemark.ocean);
                           //                           NSLog(@"areasOfInterest : %@", placemark.areasOfInterest);
                       }
                   };
}

// 測位失敗時や、5位置情報の利用をユーザーが「不許可」とした場合などに呼ばれる
- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error{
    NSLog(@"didFailWithError");
}

- (void)dealloc {
//   // [locationManager release];
//    //[textFieldName release];
//    [textFieldReceiveName release];
//    [textFieldSendName release];
//    [textFieldYear release];
//    [textFieldMonth release];
//    [textFieldDay release];
//    [textFieldHour release];
//    [textFieldMinute release];
//    [textFieldPlace release];
//    [textFieldMessage release];
//    [textFieldReceiveName release];
//    [textFieldReceiveName release];
//    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    // Release any retained subviews of the main view.
}




- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}





- (int)mainConnect:(NSString*)receiveName sendName:(NSString*)sendName year:(NSString*)year month:(NSString*)month day:(NSString*)day hour:(NSString*)hour minute:(NSString*)minute place:(NSString*)place message:(NSString*)message
{
    NSLog(@"mainConnect");
    NSString* content = @"";
    NSString* formatStr = [content stringByAppendingFormat:@"0=%@&1=%@&2=%@&3=%@&4=%@&5=%@&6=%@&7=%@&8=%@", receiveName, sendName, year, month, day, hour, minute, place, message];
    NSURL* url = [NSURL URLWithString:@"http://t-kproject.herokuapp.com/InsDB.php"];
    
    NSMutableURLRequest* urlRequest = [[NSMutableURLRequest alloc]initWithURL:url];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[formatStr dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLResponse* response;
    NSError* error = nil;
    NSData* result = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    if(error){
        
        
        NSLog(@"error = %@", error);
    }
    
    NSString* resultString
    = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    NSLog(@"%@", resultString);
    //[resultString release];
    //[urlRequest release];
    
    return YES;
}

//
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    // ソフトウェアキーボードを閉じる
    [textField resignFirstResponder];
    
    return YES;
}





- (IBAction)done:(id)sender {
    
    [self.view endEditing:YES];
}
@end