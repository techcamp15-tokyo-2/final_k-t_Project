//
//  CustomIndicatorView.h
//  storybord
//
//  Created by SZK-atmosphere on 2013/09/13.
//  Copyright (c) 2013年 夛屋 早百合. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface CustomIndicatorView : UIView
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicator;
@property (weak, nonatomic) IBOutlet UIView *view;
+ (id)customIndicatorView;
- (void)startIndicatorAnimating;
- (void)stopIndicatorAnimating;
@end
